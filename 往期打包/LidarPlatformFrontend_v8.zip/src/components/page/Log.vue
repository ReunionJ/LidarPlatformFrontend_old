<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item> <i class="el-icon-reading"></i> 日志系统 </el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <!-- 卡片视图区域 -->
        <el-card>
            <el-tabs v-model="activeName" @tab-click="handleClick">
                <el-tab-pane label="24小时内日志数据" name="first">
                    <el-table :data="logShow_new_one" style="width: 99%" stripe>
                        <el-table-column type="index"></el-table-column>
                        <el-table-column type="expand" style="background:rgba(150, 154, 184,0.05);">
                            <template slot-scope="scope">
                                <el-table :data="scope.row.children" style="width: 62%">
                                    <el-table-column prop="label4" label="生成方法名" width="180"> </el-table-column>
                                    <el-table-column prop="finish_task_number" label="已完成任务数量" width="180"> </el-table-column>
                                    <el-table-column prop="ran_task_number" label="运行中任务数量" width="180"> </el-table-column>
                                    <el-table-column prop="generate_data_number" label="生成数据数量" width="180"> </el-table-column>
                                </el-table>
                                <!-- {{ scope.row.children }} -->
                            </template>
                        </el-table-column>
                        <el-table-column prop="label1" label="日志记录时间" align="center"> </el-table-column>
                    </el-table>
                </el-tab-pane>
                <el-tab-pane label="近15天系统日志数据" name="second">
                    <el-table :data="logShow_new_two" style="width: 99%" stripe>
                        <el-table-column type="index"></el-table-column>
                        <el-table-column type="expand" style="background:rgba(150, 154, 184,0.05);">
                            <template slot-scope="scope">
                                <el-table :data="scope.row.children" style="width: 62%">
                                    <el-table-column prop="label4" label="生成方法名" width="180"> </el-table-column>
                                    <el-table-column prop="finish_task_number" label="已完成任务数量" width="180"> </el-table-column>
                                    <el-table-column prop="ran_task_number" label="运行中任务数量" width="180"> </el-table-column>
                                    <el-table-column prop="generate_data_number" label="生成数据数量" width="180"> </el-table-column>
                                </el-table>
                                <!-- {{ scope.row.children }} -->
                            </template>
                        </el-table-column>
                        <el-table-column prop="label1" label="日志记录时间" align="center"> </el-table-column>
                    </el-table>
                    <!-- <el-button @click="fileDownload">下 载</el-button> -->
                </el-tab-pane>
                <el-tab-pane label="近6个月系统日志数据" name="third">
                    <el-table :data="logShow_new_three" style="width: 99%" stripe>
                        <el-table-column type="index"></el-table-column>
                        <el-table-column type="expand" style="background:rgba(150, 154, 184,0.05);">
                            <template slot-scope="scope">
                                <el-table :data="scope.row.children" style="width: 62%">
                                    <el-table-column prop="label4" label="生成方法名" width="180"> </el-table-column>
                                    <el-table-column prop="finish_task_number" label="已完成任务数量" width="180"> </el-table-column>
                                    <el-table-column prop="ran_task_number" label="运行中任务数量" width="180"> </el-table-column>
                                    <el-table-column prop="generate_data_number" label="生成数据数量" width="180"> </el-table-column>
                                </el-table>
                                <!-- {{ scope.row.children }} -->
                            </template>
                        </el-table-column>
                        <el-table-column prop="label1" label="日志记录时间" align="center"> </el-table-column>
                    </el-table>
                    <!-- <el-button @click="fileDownload">下 载</el-button> -->
                </el-tab-pane>
            </el-tabs>
        </el-card>
    </div>
</template>

<script>
import qs from 'qs';
import fileDownload from 'js-file-download';
export default {
    name: 'baseform',

    data() {
        return {
            activeName: 'first',
            logData: {},
            logShow_old: [],
            // 用于展示表格的logShow
            logShow_new_one: [],
            logShow_new_two: [],
            logShow_new_three: [],
            logDownload: ''
        };
    },
    methods: {
        async getOne() {
            const { data: data } = await this.$http.get('log/recent_twenty_four_hours/');
            if (data.code !== 20000) {
                console.log(data.code);
                return this.$message.error('获取24小时内日志数据失败！');
            }
            this.logData = data.data;
            this.showData(1);
        },
        async getTwo() {
            const { data: data } = await this.$http.get('log/recent_fifteen_days/');
            if (data.code !== 20000) {
                console.log(data.code);
                return this.$message.error('获取近15日系统日志数据失败！');
            }
            this.logData = data.data;
            console.log('this.logData:', this.logData);
            this.showData(2);
            // this.logDownload = JSON.stringify(this.logData);
        },
        async getThree() {
            const { data: data } = await this.$http.get('log/recent_six_months/');
            if (data.code !== 20000) {
                console.log(data.code);
                return this.$message.error('获取近6个月系统日志数据失败！');
            }
            this.logData = data.data;
            this.showData(3);
        },
        handleClick(tab, event) {
            // console.log(tab, event);
        },
        fileDownload() {
            fileDownload(this.logDownload, 'logData.json');
        },
        showData(num) {
            var logShow = [];
            for (var date in this.logData) {
                // date 为时间/日期
                // var units2 = [];
                var units2_new = [];
                for (var method in this.logData[date]) {
                    // method 为方法名
                    // console.log('method:');
                    // console.log(method);
                    // var units3 = [];
                    var unit4 = {};
                    unit4 = JSON.parse(JSON.stringify(this.logData[date][method]));
                    unit4.label4 = method;
                    // console.log('unit4:');
                    // console.log(unit4);
                    // console.log('unit4:');
                    // console.log(unit4);
                    // for (var index in this.logData[date][method]) {
                    // index 为方法中的指标
                    // console.log('index:');
                    // console.log(index);
                    //     var unit3 = {};
                    //     unit3.label3 = index;
                    //     unit3.count = this.logData[date][method][index];
                    //     units3.push(unit3);
                    // }
                    // var unit2 = {};
                    // unit2.label2 = method;
                    // unit2.children = units3;
                    // units2.push(unit2);
                    units2_new.push(unit4);
                }
                // var unit1 = {};
                // unit1.label1 = date;
                // unit1.children = units2;
                // this.logShow_old.push(unit1);
                var unit1_new = {};
                unit1_new.label1 = date;
                unit1_new.children = units2_new;
                logShow.push(unit1_new);
            }
            // console.log('this.logShow_old:');
            // console.log(this.logShow_old);
            console.log('logShow:');
            console.log(logShow);
            if (num === 1) {
                this.logShow_new_one = logShow;
            } else if (num === 2) {
                this.logShow_new_two = logShow;
            } else {
                this.logShow_new_three = logShow;
            }
        }
    },
    mounted() {
        this.getOne();
        this.getTwo();
        this.getThree();
    }
};
</script>

<style scoped>
/* .table-box {
    width: 100%;

    /deep/.el-table th > .cell {
        text-align: center;
    }

    /deep/.el-table .cell {
        text-align: center;
    }
} */
.el-table,
.el-table__expanded-cell {
    background-color: #409eff;
}

.el-table th,
.el-table tr {
    background-color: #409eff;
}
</style>
