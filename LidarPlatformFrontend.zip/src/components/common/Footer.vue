<template>
    <div class="footer">Copyright ©2021 Nanjing university software institute</div>
</template>
<script>
export default {
    data() {
        return {};
    }
};
</script>

<style scoped></style>
